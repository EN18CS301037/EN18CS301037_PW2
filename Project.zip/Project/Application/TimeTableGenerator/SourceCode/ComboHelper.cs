﻿using System.Data;
using System.Windows.Forms;


namespace TimeTableGenerator.SourceCode
{
    public class ComboHelper
    {
        public static void Semesters(ComboBox cmb)
        {
            DataTable dtSemesters = new DataTable();
            dtSemesters.Columns.Add("SemesterID");
            dtSemesters.Columns.Add("SemesterName");
            dtSemesters.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select SemesterID, SemesterName from SemesterTable where IsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow sem in dt.Rows)
                        {
                            dtSemesters.Rows.Add(sem["SemesterID"], sem["SemesterName"]);
                        }
                    }

                }
                cmb.DataSource = dtSemesters;
                cmb.ValueMember = "SemesterID";
                cmb.DisplayMember = "SemesterName";
            }
            catch
            {
                cmb.DataSource = dtSemesters;
            }
        }

        public static void Programs(ComboBox cmb)
        {
            DataTable dtPrograms = new DataTable();
            dtPrograms.Columns.Add("ProgramID");
            dtPrograms.Columns.Add("ProgramName");
            dtPrograms.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select ProgramID, ProgramName from ProgramTable where IsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow program in dt.Rows)
                        {
                            dtPrograms.Rows.Add(program["ProgramID"], program["ProgramName"]);
                        }
                    }

                }
                cmb.DataSource = dtPrograms;
                cmb.ValueMember = "ProgramID";
                cmb.DisplayMember = "ProgramName";
            }
            catch
            {
                cmb.DataSource = dtPrograms;
            }
        }

        public static void RoomTypes(ComboBox cmb)
        {
            DataTable dtRoomType = new DataTable();
            dtRoomType.Columns.Add("RoomTypeID");
            dtRoomType.Columns.Add("TypeName");
            dtRoomType.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select RoomTypeID, TypeName from RoomTypeTable");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow rt in dt.Rows)
                        {
                            dtRoomType.Rows.Add(rt["RoomTypeID"], rt["TypeName"]);
                        }
                    }

                }
                cmb.DataSource = dtRoomType;
                cmb.ValueMember = "RoomTypeID";
                cmb.DisplayMember = "TypeName";
            }
            catch
            {
                cmb.DataSource = dtRoomType;
            }
        }

        public static void AllDays(ComboBox cmb)
        {
            DataTable dtDays = new DataTable();
            dtDays.Columns.Add("DayID");
            dtDays.Columns.Add("Name");
            dtDays.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select DayID, Name from DayTable where IsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow days in dt.Rows)
                        {
                            dtDays.Rows.Add(days["DayID"], days["Name"]);
                        }
                    }

                }
                cmb.DataSource = dtDays;
                cmb.ValueMember = "DayID";
                cmb.DisplayMember = "Name";
            }
            catch
            {
                cmb.DataSource = dtDays;
            }
        }

        public static void TimeSlotsNum(ComboBox cmb)
        {
            DataTable dtList = new DataTable();
            dtList.Columns.Add("ID");
            dtList.Columns.Add("Number");
            dtList.Rows.Add("0", " ----Select---- ");
            dtList.Rows.Add("1", " 1 ");
            dtList.Rows.Add("2", " 2 ");
            dtList.Rows.Add("3", " 3 ");
            dtList.Rows.Add("4", " 4 ");
            dtList.Rows.Add("5", " 5 ");
            dtList.Rows.Add("6", " 6 ");
            dtList.Rows.Add("7", " 7 ");
            dtList.Rows.Add("8", " 8 ");
            dtList.Rows.Add("9", " 9 ");
            dtList.Rows.Add("10", " 10 ");


            cmb.DataSource = dtList;
            cmb.ValueMember = "ID";
            cmb.DisplayMember = "Number";
        }

        public static void Faculty(ComboBox cmb)
        {
            DataTable dtList = new DataTable();
            dtList.Columns.Add("FacultyID");
            dtList.Columns.Add("FullName");
            dtList.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select FacultyID, FullName from TeacherTable where IsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow faculty in dt.Rows)
                        {
                            dtList.Rows.Add(faculty["FacultyID"], faculty["FullName"]);
                        }
                    }

                }
                cmb.DataSource = dtList;
                cmb.ValueMember = "FacultyID";
                cmb.DisplayMember = "FullName";
            }
            catch
            {
                cmb.DataSource = dtList;
            }
        }

        public static void Subject(ComboBox cmb)
        {
            DataTable dtList = new DataTable();
            dtList.Columns.Add("CourseID");
            dtList.Columns.Add("Title");
            dtList.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select CourseID, Title from CourseTable where IsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow course in dt.Rows)
                        {
                            dtList.Rows.Add(course["CourseID"], course["Title"]);
                        }
                    }

                }
                cmb.DataSource = dtList;
                cmb.ValueMember = "CourseID";
                cmb.DisplayMember = "Title";
            }
            catch
            {
                cmb.DataSource = dtList;
            }
        }

        public static void AllProgramSems(ComboBox cmb)
        {
            DataTable dtList = new DataTable();
            dtList.Columns.Add("ProgramSemesterID");
            dtList.Columns.Add("Title");
            dtList.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select ProgramSemesterID, Title from v_ProgramSemesterActiveList where ProgramSemesterIsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow program in dt.Rows)
                        {
                            dtList.Rows.Add(program["ProgramSemesterID"], program["Title"]);
                        }
                    }

                }
                cmb.DataSource = dtList;
                cmb.ValueMember = "ProgramSemesterID";
                cmb.DisplayMember = "Title";
            }
            catch
            {
                cmb.DataSource = dtList;
            }
        }

        public static void AllFacultySubjects(ComboBox cmb)
        {
            DataTable dtList = new DataTable();
            dtList.Columns.Add("FacultySubjectID");
            dtList.Columns.Add("SubjectTitle");
            dtList.Rows.Add("0", " ----Select----");
            try
            {
                DataTable dt = DBLayer.Retrieve("Select FacultySubjectID, SubjectTitle from v_AllSubjectTeachers where IsActive = 1 ");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        foreach (DataRow program in dt.Rows)
                        {
                            dtList.Rows.Add(program["FacultySubjectID"], program["SubjectTitle"]);
                        }
                    }

                }
                cmb.DataSource = dtList;
                cmb.ValueMember = "FacultySubjectID"; 
                cmb.DisplayMember = "SubjectTitle";
            }
            catch
            {
                cmb.DataSource = dtList;
            }
        }

    }
}
  