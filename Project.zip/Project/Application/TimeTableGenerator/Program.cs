﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.Forms;
using TimeTableGenerator.Forms.Configuration_Forms;
using TimeTableGenerator.Forms.FacultySubjectForms;
using TimeTableGenerator.Forms.ProgramSemesterForms;
using TimeTableGenerator.Forms.TimeSlotForms;
using TimeTableGenerator.Reports;

namespace TimeTableGenerator
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new SessionForm());
            //Application.Run(new SemesterForm());
            //Application.Run(new ProgramForm()); 
            //Application.Run(new DaysForm());
            //Application.Run(new RoomForm());
            //Application.Run(new LabForm());
            //Application.Run(new FacultyForm());
            //Application.Run(new CoursesForm());
            //Application.Run(new ProgramSemesterForm());
            //Application.Run(new DayTimeSlotsForm());
            //Application.Run(new FacultySubjectForm());
            //Application.Run(new ProgramSemSubForm());
            //Application.Run(new SemesterSectionForm());
            //Application.Run(new GenerateTimeTablesForm());
             //Application.Run(new Home());
             Application.Run(new LoginForm());
            //Application.Run(new PrintAllSemTt());
            // Application.Run(new PrintAllTeachersTT());
        }
    }
}
