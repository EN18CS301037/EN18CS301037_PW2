﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.Forms.Configuration_Forms;
using TimeTableGenerator.Forms.FacultySubjectForms;
using TimeTableGenerator.Forms.ProgramSemesterForms;
using TimeTableGenerator.Forms.TimeSlotForms;
using TimeTableGenerator.Reports;

namespace TimeTableGenerator.Forms
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void btnProgram_Click(object sender, EventArgs e)
        {
            ProgramForm frm = new ProgramForm();
            frm.ShowDialog();
        }

        private void btnSubjects_Click(object sender, EventArgs e)
        {
            
            CoursesForm frm = new CoursesForm();
            frm.ShowDialog();
        }

        private void btnSessions_Click(object sender, EventArgs e)
        {
            SessionForm frm = new SessionForm();
            frm.ShowDialog();
        }

        private void btnAddNewFaculty_Click(object sender, EventArgs e)
        {
            FacultyForm frm = new FacultyForm();
            frm.ShowDialog();
        }

        private void btnAssignSubjectsToFaculty_Click(object sender, EventArgs e)
        {
            FacultySubjectForm frm = new FacultySubjectForm();
            frm.ShowDialog();
        }

        private void btnAddRooms_Click(object sender, EventArgs e)
        {
            RoomForm frm = new RoomForm();
            frm.ShowDialog();
        }

        private void btnAddLabs_Click(object sender, EventArgs e)
        {
            LabForm frm = new LabForm();
            frm.ShowDialog();
        }

        private void btnnewSemester_Click(object sender, EventArgs e)
        {
            SemesterForm frm = new SemesterForm();
            frm.ShowDialog();
        }

        private void btnAddSectionsToSemester_Click(object sender, EventArgs e)
        {
            SemesterSectionForm frm = new SemesterSectionForm();
            frm.ShowDialog();
        }

        private void btnAddSemesterToProgram_Click(object sender, EventArgs e)
        {
            ProgramSemesterForm frm = new ProgramSemesterForm();
            frm.ShowDialog();
        }

        private void btnAddSubjectToSemester_Click(object sender, EventArgs e)
        {
            ProgramSemSubForm frm = new ProgramSemSubForm();
            frm.ShowDialog();
        }

        private void btnAddDays_Click(object sender, EventArgs e)
        {
            DaysForm frm = new DaysForm();
            frm.ShowDialog();
        }

        private void btnDayTimeSlots_Click(object sender, EventArgs e)
        {
            DayTimeSlotsForm frm = new DayTimeSlotsForm();
            frm.ShowDialog();
        }

        private void btnAutoGenerateTimeTable_Click(object sender, EventArgs e)
        {
            GenerateTimeTablesForm frm = new GenerateTimeTablesForm();
            frm.ShowDialog();
        }

        private void btnPrintStudentTT_Click(object sender, EventArgs e)
        {
            PrintAllSemTt frm = new PrintAllSemTt();
            frm.ShowDialog();
        }

        private void btnPrintFacultyTT_Click(object sender, EventArgs e)
        {
            PrintAllTeachersTT frm = new PrintAllTeachersTT();
            frm.ShowDialog();
        }
    }
}
