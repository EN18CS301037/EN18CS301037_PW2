﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.AllModels;
using TimeTableGenerator.SourceCode;

namespace TimeTableGenerator.Forms.TimeSlotForms
{
    public partial class DayTimeSlotsForm : Form
    {
        public DayTimeSlotsForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select DayTimeSlotID,Row_Number() Over (order by DayTimeSlotID) As [Sno] , DayID, Name [Day], SlotTitle [Slot Title], StartTime [Start Time], EndTime [End Time], IsActive  from v_AllTimeSlots";
                }
                else
                {
                    query = "select DayTimeSlotID, Row_Number() Over (order by DayTimeSlotID) As [Sno], DayID, Name [Day], SlotTitle [Slot Title], StartTime [Start Time], EndTime [End Time], IsActive  from v_AllTimeSlots where IsActive = 1 AND (Name +' '+ SlotTitle)  like '%" + searchvalue.Trim() + "%'";
                }

                DataTable facultylist = DBLayer.Retrieve(query);
                dgvSlots.DataSource = facultylist;
                if (dgvSlots.Rows.Count > 0)
                {
                    dgvSlots.Columns[0].Visible = false; ;
                    dgvSlots.Columns[1].Width = 100;
                    dgvSlots.Columns[2].Visible = false;
                    dgvSlots.Columns[3].Width = 150;
                    dgvSlots.Columns[4].Width = 150;
                    dgvSlots.Columns[5].Width = 100;
                    dgvSlots.Columns[6].Width = 100;
                    dgvSlots.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        private void DayTimeSlotsForm_Load(object sender, EventArgs e)
        {
            dtpstarttime.Value = new DateTime(2021,12,12,8,0,0);
            dtpendtime.Value = new DateTime(2021, 12, 12, 17, 0, 0);
            ComboHelper.AllDays(cmbdays);
            ComboHelper.TimeSlotsNum(cmbnooftimeslot);
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        public void ClearForm()
        {
           // txtname.Clear();
            cmbdays.SelectedIndex = 0;
            cmbnooftimeslot.SelectedIndex = 0;
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void SaveClearForm()
        {
           // txtname.Clear();
            chkstatus.Checked = true;
            FillGrid(string.Empty);

        }

        public void EnableComponents()
        {
            dgvSlots.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvSlots.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if(dgvSlots != null)
            {
                if(dgvSlots.Rows.Count > 0)
                {
                    if (dgvSlots.SelectedRows.Count == 1)
                    {
                        string slotid = Convert.ToString(dgvSlots.CurrentRow.Cells[0].Value);
                        string updatequery = "Update DayTimeSlotTable set IsActive =0 where  DayTimeSlotID= '" + Convert.ToString(dgvSlots.CurrentRow.Cells[0].Value) + "'";
                        bool result = DBLayer.Update(updatequery);
                        if(result == true)
                        {
                            MessageBox.Show("Break Time is marked");
                            DisableComponents();
                        }

                    }
                }

            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cmbdays.SelectedIndex == 0)
                {
                    ep.SetError(cmbdays, "Please select day!!");
                    cmbdays.Focus();
                    //txtname.SelectAll();
                    return;
                }

                if (cmbnooftimeslot.SelectedIndex == 0)
                {
                    ep.SetError(cmbnooftimeslot, "Please Select Number of time slots per day!!");
                    cmbnooftimeslot.Focus();
                    return;
                }

                List<TimeSlotsMV> timeSlots = new List<TimeSlotsMV>();
                TimeSpan time = dtpendtime.Value - dtpstarttime.Value;
                int totalminuts = (int)time.TotalMinutes;
                int numberoftimslots = Convert.ToInt32(cmbnooftimeslot.SelectedValue);
                int slot = totalminuts / numberoftimslots;
               // TimeSpan starttime = dtpstarttime.Value.TimeOfDay;
                int i = 0;
                do
                {
                    var timeslot = new TimeSlotsMV();
                    var FromTime = (dtpstarttime.Value).AddMinutes(slot * i);
                    i++;
                    var ToTime = (dtpstarttime.Value).AddMinutes(slot * i);
                    string title = FromTime.ToString("hh:mm:tt") + "-" + ToTime.ToString("hh:mm:tt");
                    timeslot.FromTime = FromTime;
                    timeslot.ToTime = ToTime;
                    timeslot.SlotTitle = title;//e
                   // timeslot.Add(timeslot);//e
                } while (i < numberoftimslots);

                bool insertstatus = true;
                foreach (TimeSlotsMV slottime in timeSlots)
                {
                    string insertquery = string.Format("insert into DayTimeSlotTable(DayID,SlotTitle,StartTime,EndTime,IsActive) values('{0}','{1}','{2}','{3}','{4}')", cmbdays.SelectedValue, slottime.SlotTitle, slottime.FromTime, slottime.ToTime, chkstatus.Checked);
                    bool result = DBLayer.Insert(insertquery);
                    if (result == false)
                    {
                        insertstatus = false;
                    }
                }
                if (insertstatus == true)
                {
                    MessageBox.Show("Slots created Successfully!!");
                    DisableComponents();
                }
                else
                {
                    MessageBox.Show("Please provide Correct Details & try again");
                }
            }
            catch 
            {
                MessageBox.Show("check Sql Server Agent Connectivity");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

        }
    }
}
