﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class RoomForm : Form
    {
        public RoomForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select RoomID [ID], RoomNumber [Room], Capacity, IsActive [Status] from RoomTable";
                }
                else
                {
                    query = "select RoomID [ID], RoomNumber [Room], Capacity, IsActive [Status] from RoomTable where RoomNumber like '%" + searchvalue.Trim() + "%'";
                }

                DataTable roomlist = DBLayer.Retrieve(query);
                dgvroom.DataSource = roomlist;
                if (dgvroom.Rows.Count > 0)
                {
                    dgvroom.Columns[0].Width = 80;
                    dgvroom.Columns[1].Width = 80;
                    dgvroom.Columns[2].Width = 80;
                    dgvroom.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        private void txtcapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void RoomForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtroomnumber.Text.Length == 0 || txtroomnumber.Text.Length > 10)
            {
                ep.SetError(txtroomnumber, "Please enter correct room number!!");
                txtroomnumber.Focus();
                txtroomnumber.SelectAll();
                return;
            }

            if (txtcapacity.Text.Length == 0)
            {
                ep.SetError(txtcapacity, "Please enter room capacity!!");
                txtcapacity.Focus();
                txtcapacity.SelectAll();
                return;
            }
            DataTable checktitle = DBLayer.Retrieve("select * from RoomTable where RoomNumber= '" + txtroomnumber.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtroomnumber, "Room Already Exists!!");
                    txtroomnumber.Focus();
                    txtroomnumber.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into RoomTable(RoomNumber,Capacity,IsActive) values('{0}','{1}','{2}')", txtroomnumber.Text.Trim(), txtcapacity.Text.Trim(), chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct room details and try again!!");
            }

        }

        public void ClearForm()
        {
            txtroomnumber.Clear();
            txtcapacity.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void EnableComponents()
        {
            dgvroom.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvroom.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvroom != null)
            {
                if (dgvroom.Rows.Count > 0)
                {
                    if (dgvroom.SelectedRows.Count == 1)
                    {
                        txtroomnumber.Text = Convert.ToString(dgvroom.CurrentRow.Cells[1].Value);
                        txtcapacity.Text = Convert.ToString(dgvroom.CurrentRow.Cells[2].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvroom.CurrentRow.Cells[3].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtroomnumber.Text.Length == 0 || txtroomnumber.Text.Length > 10)
            {
                ep.SetError(txtroomnumber, "Please enter correct room number!!");
                txtroomnumber.Focus();
                txtroomnumber.SelectAll();
                return;
            }

            if (txtcapacity.Text.Length == 0)
            {
                ep.SetError(txtcapacity, "Please enter room capacity!!");
                txtcapacity.Focus();
                txtcapacity.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from RoomTable where RoomNumber= '" + txtroomnumber.Text.Trim() + "' and RoomID != '" + Convert.ToString(dgvroom.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtroomnumber, "Room Already Exists!!");
                    txtroomnumber.Focus();
                    txtroomnumber.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update RoomTable set RoomNumber='{0}', Capacity='{1}', IsActive='{2}' where RoomID = '{3}'", txtroomnumber.Text.Trim(), txtcapacity.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvroom.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Room details and try again!!");
            }
        }
    }
}
