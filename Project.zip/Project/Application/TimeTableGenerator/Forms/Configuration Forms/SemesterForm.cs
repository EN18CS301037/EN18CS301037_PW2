﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class SemesterForm : Form
    {
        public SemesterForm()
        {
            InitializeComponent();
        }
        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select SemesterID [ID], SemesterName [Semester], IsActive [Status] from SemesterTable";
                }
                else
                {
                    query = "select SemesterID [ID], SemesterName [Semester], IsActive [Status] from SemesterTable where SemesterName like '%" + searchvalue.Trim() + "%'";
                }

                DataTable semesterlist = DBLayer.Retrieve(query);
                dgvsemester.DataSource = semesterlist;
                if (dgvsemester.Rows.Count > 0)
                {
                    dgvsemester.Columns[0].Width = 80;
                    dgvsemester.Columns[1].Width = 150;
                    dgvsemester.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }
        private void SemesterForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtsemestername.Text.Length < 9)
            {
                ep.SetError(txtsemestername, "Please enter semester!!");
                txtsemestername.Focus();
                txtsemestername.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from SemesterTable where SemesterName= '" + txtsemestername.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtsemestername, "Session Already Exists!!");
                    txtsemestername.Focus();
                    txtsemestername.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into SemesterTable(SemesterName,IsActive) values('{0}','{1}')", txtsemestername.Text.Trim(), chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct semester details and try again!!");
            }

        }

        public void ClearForm()
        {
            txtsemestername.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void EnableComponents()
        {
            dgvsemester.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvsemester.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvsemester != null)
            {
                if (dgvsemester.Rows.Count > 0)
                {
                    if (dgvsemester.SelectedRows.Count == 1)
                    {
                        txtsemestername.Text = Convert.ToString(dgvsemester.CurrentRow.Cells[1].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvsemester.CurrentRow.Cells[2].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtsemestername.Text.Length < 9)
            {
                ep.SetError(txtsemestername, "Enter Correct Semester!!");
                txtsemestername.Focus();
                txtsemestername.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from SemesterTable where SemesterName = '" + txtsemestername.Text.Trim() + "' and SemesterID != '" + Convert.ToString(dgvsemester.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtsemestername, "Semester Already Exists!!");
                    txtsemestername.Focus();
                    txtsemestername.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update SemesterTable set SemesterName='{0}',IsActive='{1}' where SemesterID = '{2}'", txtsemestername.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvsemester.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Semester details and try again!!");
            }

        }
    }
}
