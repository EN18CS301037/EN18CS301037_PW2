﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class FacultyForm : Form
    {
        public FacultyForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select FacultyID [ID], FullName [Name], Email [Email], IsActive [Status] from TeacherTable order by FullName";
                }
                else
                {
                    query = "select FacultyID [ID], FullName [Name], Email [Email], IsActive [Status] from TeacherTable where FullName like '%" + searchvalue.Trim() + "%' order by FullName";
                }

                DataTable facultylist = DBLayer.Retrieve(query);
                dgvfaculty.DataSource = facultylist;
                if (dgvfaculty.Rows.Count > 0)
                {
                    dgvfaculty.Columns[0].Width = 80;
                    dgvfaculty.Columns[1].Width = 150;
                    //dgvlab.Columns[2].Width = 80;
                    dgvfaculty.Columns[2].Width = 200;
                    dgvfaculty.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }
        private void txtcapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void FacultyForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtname.Text.Length == 0)
            {
                ep.SetError(txtname, "Please enter name!!");
                txtname.Focus();
                txtname.SelectAll();
                return;
            }

           /* if (txtcontactno.Text.Length == 0)
            {
                ep.SetError(txtcontactno, "Please enter Contact number!!");
                txtcontactno.Focus();
                txtcontactno.SelectAll();
                return;
            }*/

            if (txtemail.Text.Length == 0)
            {
                ep.SetError(txtemail, "Please enter email!!");
                txtemail.Focus();
                txtemail.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from TeacherTable where FullName= '" + txtname.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtname, "Faulty Already Exists!!");
                    txtname.Focus();
                    txtname.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into TeacherTable(FullName,Email,IsActive) values('{0}','{1}','{2}')", txtname.Text.Trim(), txtemail.Text.Trim(),chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Faculty details and try again!!");
            }
        }

        public void ClearForm()
        {
            txtname.Clear();
            //txtcontactno.Clear();
            txtemail.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void EnableComponents()
        {
            dgvfaculty.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvfaculty.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvfaculty != null)
            {
                if (dgvfaculty.Rows.Count > 0)
                {
                    if (dgvfaculty.SelectedRows.Count == 1)
                    {
                        txtname.Text = Convert.ToString(dgvfaculty.CurrentRow.Cells[1].Value);
                      //txtcontactno.Text = Convert.ToString(dgvlab.CurrentRow.Cells[2].Value);
                        txtemail.Text = Convert.ToString(dgvfaculty.CurrentRow.Cells[2].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvfaculty.CurrentRow.Cells[3].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtname.Text.Length == 0 || txtname.Text.Length > 100)
            {
                ep.SetError(txtname, "Please enter correct Name!!");
                txtname.Focus();
                txtname.SelectAll();
                return;
            }

            if (txtemail.Text.Length == 0)
            {
                ep.SetError(txtemail, "Please enter correct Email!!");
                txtemail.Focus();
                txtemail.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from TeacherTable where FullName= '" + txtname.Text.Trim() + "' and FacultyID != '" + Convert.ToString(dgvfaculty.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtname, "Faculty Already Exists!!");
                    txtemail.Focus();
                    txtemail.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update TeacherTable set FullName='{0}', Email='{1}', IsActive='{2}' where FacultyID = '{3}'", txtname.Text.Trim(), txtemail.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvfaculty.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Faculty details and try again!!");
            }
        }
    }
}
