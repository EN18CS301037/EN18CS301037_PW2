﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class ProgramForm : Form
    {
        public ProgramForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select ProgramID [ID], ProgramName [Program] , IsActive [Status] from ProgramTable";
                }
                else
                {
                    query = "select ProgramID [ID], ProgramName [Program], IsActive [Status] from ProgramTable where ProgramName like '%" + searchvalue.Trim() + "%'";
                }

                DataTable programlist = DBLayer.Retrieve(query);
                dgvprogram.DataSource = programlist;
                if (dgvprogram.Rows.Count > 0)
                {
                    dgvprogram.Columns[0].Width = 80;
                    dgvprogram.Columns[1].Width = 150;
                    dgvprogram.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        private void ProgramForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtprogramname.Text.Length < 4)
            {
                ep.SetError(txtprogramname, "Please enter Program!!");
                txtprogramname.Focus();
                txtprogramname.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from ProgramTable where ProgramName= '" + txtprogramname.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtprogramname, "Program Already Exists!!");
                    txtprogramname.Focus();
                    txtprogramname.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into ProgramTable(ProgramName,IsActive) values('{0}','{1}')", txtprogramname.Text.Trim(), chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct semester details and try again!!");
            }
        }

        public void ClearForm()
        {
            txtprogramname.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void EnableComponents()
        {
            dgvprogram.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvprogram.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvprogram != null)
            {
                if (dgvprogram.Rows.Count > 0)
                {
                    if (dgvprogram.SelectedRows.Count == 1)
                    {
                        txtprogramname.Text = Convert.ToString(dgvprogram.CurrentRow.Cells[1].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvprogram.CurrentRow.Cells[2].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtprogramname.Text.Length < 9)
            {
                ep.SetError(txtprogramname, "Enter Correct Program!!");
                txtprogramname.Focus();
                txtprogramname.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from ProgramTable where ProgramName= '" + txtprogramname.Text.Trim() + "' and ProgramID != '" + Convert.ToString(dgvprogram.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    //ep.SetError(txtprogramname, "Program Already Exists!!");
                    txtprogramname.Focus();
                    txtprogramname.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update ProgramTable set ProgramName='{0}',IsActive='{1}' where ProgramID = '{2}'", txtprogramname.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvprogram.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Program details and try again!!");
            }
        }
    }
}
