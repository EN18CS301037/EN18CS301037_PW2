﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.SourceCode;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class CoursesForm : Form
    {
        public CoursesForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select CourseID [ID], Title [Subject Name],Credits,Hours,RoomTypeID,TypeName [Type], IsActive from v_Allsubjects";
                }
                else
                {
                    query = "select CourseID [ID], Title [Subject Name],Credits,Hours,RoomTypeID,TypeName [Type], IsActive from v_Allsubjects where (Title +' '+ TypeName)  like '%" + searchvalue.Trim() + "%'";
                }

                DataTable facultylist = DBLayer.Retrieve(query);
                dgvSubject.DataSource = facultylist;
                if (dgvSubject.Rows.Count > 0)
                {
                    dgvSubject.Columns[0].Width = 50;
                    dgvSubject.Columns[1].Width = 250;
                    dgvSubject.Columns[2].Width = 50;
                    dgvSubject.Columns[3].Width = 50;
                    dgvSubject.Columns[4].Visible = false;
                    dgvSubject.Columns[5].Width = 150;
                    dgvSubject.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        private void CoursesForm_Load(object sender, EventArgs e)
        {
            //cmbcredits.SelectedIndex = 0;
           // cmbhours.SelectedIndex = 0;
           // cmbselecttype.SelectedIndex = 0;
            ComboHelper.RoomTypes(cmbselecttype);
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        public void ClearForm()
        {
            txtname.Clear();
            cmbselecttype.SelectedIndex = 0;
            cmbcredits.SelectedIndex = 0;
            cmbhours.SelectedIndex = 0;
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void SaveClearForm()
        {
            txtname.Clear();
            chkstatus.Checked = true;
            FillGrid(string.Empty);

        }

        public void EnableComponents()
        {
            dgvSubject.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvSubject.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvSubject != null)
            {
                if (dgvSubject.Rows.Count > 0)
                {
                    if (dgvSubject.SelectedRows.Count == 1)
                    {
                        txtname.Text = Convert.ToString(dgvSubject.CurrentRow.Cells[1].Value);
                        cmbselecttype.SelectedValue = Convert.ToString(dgvSubject.CurrentRow.Cells[4].Value);
                        cmbcredits.Text = Convert.ToString(dgvSubject.CurrentRow.Cells[2].Value);
                        cmbhours.Text = Convert.ToString(dgvSubject.CurrentRow.Cells[3].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvSubject.CurrentRow.Cells[6].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtname.Text.Length == 0)
            {
                ep.SetError(txtname, "Please enter subject name!!");
                txtname.Focus();
                txtname.SelectAll();
                return;
            }

            if (cmbselecttype.SelectedIndex == 0)
            {
                ep.SetError(cmbselecttype, "Please Select Room Type!!");
                cmbselecttype.Focus();
                cmbselecttype.SelectAll();
                return;
            }

            if (cmbcredits.SelectedIndex == 0)
            {
                ep.SetError(cmbcredits, "Please Select Credits!!");
                cmbcredits.Focus();
                cmbcredits.SelectAll();
                return;
            }

            if (cmbhours.SelectedIndex == 0)
            {
                ep.SetError(cmbhours, "Please Select Hours!!");
                cmbhours.Focus();
                cmbhours.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from CourseTable where Title= '" + txtname.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtname, " Already Exists!!");
                    txtname.Focus();
                    txtname.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into CourseTable(Title,Credits,Hours,RoomTypeID,IsActive) values('{0}','{1}','{2}','{3}','{4}')", txtname.Text.Trim(), cmbcredits.Text, cmbhours.Text, cmbselecttype.SelectedValue, chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                SaveClearForm();
            }
            else
            {
                MessageBox.Show("Please provide correct details and try again!!");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtname.Text.Length == 0)
            {
                ep.SetError(txtname, "Please enter subject name!!");
                txtname.Focus();
                txtname.SelectAll();
                return;
            }

            if (cmbselecttype.SelectedIndex == 0)
            {
                ep.SetError(cmbselecttype, "Please Select Room Type!!");
                cmbselecttype.Focus();
                cmbselecttype.SelectAll();
                return;
            }

            if (cmbcredits.SelectedIndex == 0)
            {
                ep.SetError(cmbcredits, "Please Select Credits!!");
                cmbcredits.Focus();
                cmbcredits.SelectAll();
                return;
            }

            if (cmbhours.SelectedIndex == 0)
            {
                ep.SetError(cmbhours, "Please Select Hours!!");
                cmbhours.Focus();
                cmbhours.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from CourseTable where Title= '" + txtname.Text.Trim() + "' and CourseID != '" + Convert.ToString(dgvSubject.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtname, " Already Exists!!");
                    txtname.Focus();
                    txtname.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update CourseTable set Title='{0}', Credits='{1}', Hours= '{2}',RoomTypeID = '{3}', IsActive='{4}' where CourseID = '{5}'", txtname.Text.Trim(), cmbcredits.Text, cmbhours.Text, cmbselecttype.SelectedValue, chkstatus.Checked, Convert.ToString(dgvSubject.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct details and try again!!");
            }
        }
    }
       
}
// insert [dbo].[CourseTable] ([RoomTypeID],[Name],[Credits],[Hours],[IsActive]) Values (3, N'Basic Electronics',3,1);