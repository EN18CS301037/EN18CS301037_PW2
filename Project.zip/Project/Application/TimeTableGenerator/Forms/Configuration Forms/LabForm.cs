﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class LabForm : Form
    {
        public LabForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select LabID [ID], LabNumber [Lab], Capacity, IsActive [Status] from LabTable";
                }
                else
                {
                    query = "select LabID [ID], LabNumber [Lab], Capacity, IsActive [Status] from LabTable where LabNumber like '%" + searchvalue.Trim() + "%'";
                }

                DataTable lablist = DBLayer.Retrieve(query);
                dgvlab.DataSource = lablist;
                if (dgvlab.Rows.Count > 0)
                {
                    dgvlab.Columns[0].Width = 80;
                    dgvlab.Columns[1].Width = 80;
                    dgvlab.Columns[2].Width = 80;
                    dgvlab.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        private void txtcapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void LabForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtlabnumber.Text.Length == 0 || txtlabnumber.Text.Length > 10)
            {
                ep.SetError(txtlabnumber, "Please enter correct lab number!!");
                txtlabnumber.Focus();
                txtlabnumber.SelectAll();
                return;
            }

            if (txtcapacity.Text.Length == 0)
            {
                ep.SetError(txtcapacity, "Please enter lab capacity!!");
                txtcapacity.Focus();
                txtcapacity.SelectAll();
                return;
            }
            DataTable checktitle = DBLayer.Retrieve("select * from LabTable where LabNumber= '" + txtlabnumber.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtlabnumber, "Lab room Already Exists!!");
                    txtlabnumber.Focus();
                    txtlabnumber.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into LabTable(LabNumber,Capacity,IsActive) values('{0}','{1}','{2}')", txtlabnumber.Text.Trim(), txtcapacity.Text.Trim(), chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Lab details and try again!!");
            }
        }

        public void ClearForm()
        {
            txtlabnumber.Clear();
            txtcapacity.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void EnableComponents()
        {
            dgvlab.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvlab.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if(dgvlab != null)
            {
                if (dgvlab.Rows.Count > 0)
                {
                    if (dgvlab.SelectedRows.Count == 1)
                    {
                        txtlabnumber.Text = Convert.ToString(dgvlab.CurrentRow.Cells[1].Value);
                        txtcapacity.Text = Convert.ToString(dgvlab.CurrentRow.Cells[2].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvlab.CurrentRow.Cells[3].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtlabnumber.Text.Length == 0 || txtlabnumber.Text.Length > 10)
            {
                ep.SetError(txtlabnumber, "Please enter correct Lab number!!");
                txtlabnumber.Focus();
                txtlabnumber.SelectAll();
                return;
            }

            if (txtcapacity.Text.Length == 0)
            {
                ep.SetError(txtlabnumber, "Please enter Lab capacity!!");
                txtlabnumber.Focus();
                txtlabnumber.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from LabTable where LabNumber= '" + txtlabnumber.Text.Trim() + "' and LabID != '" + Convert.ToString(dgvlab.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtcapacity, "Lab Room Already Exists!!");
                    txtcapacity.Focus();
                    txtcapacity.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update LabTable set LabNumber='{0}', Capacity='{1}', IsActive='{2}' where LabID = '{3}'", txtlabnumber.Text.Trim(), txtcapacity.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvlab.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Lab details and try again!!");
            }

        }
    }
}
