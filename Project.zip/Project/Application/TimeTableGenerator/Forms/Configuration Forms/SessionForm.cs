﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class SessionForm : Form
    {
        public SessionForm()
        {
            InitializeComponent();
        }

        public object DatabaseLayer { get; private set; }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select SessionID [ID], Title [Name], IsActive [Status] from SessionTable";
                }
                else
                {
                    query = "select SessionID [ID], Title [Name], IsActive [Status] from SessionTable where Title like '%" + searchvalue.Trim() + "%'";
                }

                DataTable sessionlist = DBLayer.Retrieve(query);
                 dgvsessions.DataSource = sessionlist;
                if (dgvsessions.Rows.Count > 0)
                {
                    dgvsessions.Columns[0].Width = 80;
                    dgvsessions.Columns[1].Width = 150;
                    dgvsessions.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;


                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
               
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SessionForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtSessiontitle.Text.Length == 0)
            {
                ep.SetError(txtSessiontitle, "Enter Correct Session!!");
                txtSessiontitle.Focus();
                txtSessiontitle.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from SessionTable where Title = '" + txtSessiontitle.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtSessiontitle, "Session Already Exists!!");
                    txtSessiontitle.Focus();
                    txtSessiontitle.SelectAll();
                    return;
                }
            }
            string insertquery = string.Format("insert into SessionTable(Title,IsActive) values('{0}','{1}')", txtSessiontitle.Text.Trim(), chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct session details and try again!!");
            }
        }

        public void ClearForm()
        {
            txtSessiontitle.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        { 
            ep.Clear();
            if (txtSessiontitle.Text.Length == 0)
            {
                ep.SetError(txtSessiontitle, "Enter Correct Session!!");
                txtSessiontitle.Focus();
                txtSessiontitle.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from SessionTable where Title= '" + txtSessiontitle.Text.Trim() + "' and SessionID != '" + Convert.ToString(dgvsessions.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtSessiontitle, "Session Already Exists!!");
                    txtSessiontitle.Focus();
                    txtSessiontitle.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update SessionTable set Title = '{0}',IsActive='{1}' where SessionID = '{2}'", txtSessiontitle.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvsessions.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct session details and try again!!");
            }

        }

        public void EnableComponents()
        {
            dgvsessions.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvsessions.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvsessions != null)
            {
                if (dgvsessions.Rows.Count > 0)
                {
                    if (dgvsessions.SelectedRows.Count == 1)
                    {
                        txtSessiontitle.Text = Convert.ToString(dgvsessions.CurrentRow.Cells[1].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvsessions.CurrentRow.Cells[2].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void txtSessiontitle_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
