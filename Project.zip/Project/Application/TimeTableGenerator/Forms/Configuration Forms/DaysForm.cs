﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTableGenerator.Forms.Configuration_Forms
{
    public partial class DaysForm : Form
    {
        public DaysForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select DayID [ID], Name [Day] , IsActive [Status] from DayTable";
                }
                else
                {
                    query = "select DayID [ID], Name [Day], IsActive [Status] from DayTable where Name like '%" + searchvalue.Trim() + "%'";
                }

                DataTable daylist = DBLayer.Retrieve(query);
                dgvday.DataSource = daylist;
                if (dgvday.Rows.Count > 0)
                {
                    dgvday.Columns[0].Width = 80;
                    dgvday.Columns[1].Width = 150;
                    dgvday.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }
        private void DaysForm_Load(object sender, EventArgs e)
        {
            FillGrid(string.Empty);
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtdayname.Text.Length == 0)
            {
                ep.SetError(txtdayname, "Please enter Day!!");
                txtdayname.Focus();
                txtdayname.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from DayTable where Name= '" + txtdayname.Text.Trim() + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtdayname, "Day Already Exists!!");
                    txtdayname.Focus();
                    txtdayname.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into DayTable(Name,IsActive) values('{0}','{1}')", txtdayname.Text.Trim(), chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct semester details and try again!!");
            }
        }

        public void ClearForm()
        {
            txtdayname.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void EnableComponents()
        {
            dgvday.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvday.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }


       private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvday != null)
            {
                if (dgvday.Rows.Count > 0)
                {
                    if (dgvday.SelectedRows.Count == 1)
                    {
                        txtdayname.Text = Convert.ToString(dgvday.CurrentRow.Cells[1].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvday.CurrentRow.Cells[2].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtdayname.Text.Length == 0)
            {
                ep.SetError(txtdayname, "Enter Correct Day!!");
                txtdayname.Focus();
                txtdayname.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from DayTable where Name= '" + txtdayname.Text.Trim() + "' and DayID != '" + Convert.ToString(dgvday.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtdayname, "Day Already Exists!!");
                    txtdayname.Focus();
                    txtdayname.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update DayTable set Name='{0}',IsActive='{1}' where DayID = '{2}'", txtdayname.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvday.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct Day details and try again!!");
            }
        }
    }
}
