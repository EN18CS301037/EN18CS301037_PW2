﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.SourceCode;

namespace TimeTableGenerator.Forms.ProgramSemesterForms
{
    public partial class ProgramSemesterForm : Form
    {
        public ProgramSemesterForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "Select ProgramSemesterID [ID], Title, Capacity, ProgramSemesterIsActive [Status], ProgramID, SemesterID  from v_ProgramSemesterActiveList";
                }
                else
                {
                    query = "Select ProgramSemesterID [ID], Title, Capacity, ProgramSemesterIsActive [Status], ProgramID, SemesterID  from v_ProgramSemesterActiveList where Title like '%" + searchvalue.Trim() + "%'";
                }

                DataTable lablist = DBLayer.Retrieve(query);
                dgvProgSem.DataSource = lablist;
                if (dgvProgSem.Rows.Count > 0)
                {
                    dgvProgSem.Columns[0].Width = 80;  //ProgramsemID
                    dgvProgSem.Columns[1].Width = 250;  //name
                    dgvProgSem.Columns[2].Width = 80;   //cap
                    dgvProgSem.Columns[3].Width = 80;   //status
                    dgvProgSem.Columns[4].Visible = false;   //progID
                    dgvProgSem.Columns[5].Visible = false;    //SemID

                }
            }
            catch (Exception)
            {

                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        private void ProgramSemesterForms_Load(object sender, EventArgs e)
        {
            ComboHelper.Semesters(cmbselectsemester);
            ComboHelper.Programs(cmbselectprogram);
            FillGrid(string.Empty);
        }

        private void cmbselectprogram_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(!cmbselectprogram.Text.Contains("Select"))
            {
                if(cmbselectsemester.SelectedIndex > 0)
                {
                    txtname.Text = cmbselectprogram.Text + " " + cmbselectsemester.Text;
                }
            }
        }

        private void cmbselectsemester_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!cmbselectsemester.Text.Contains("Select"))
            {
                if (cmbselectprogram.SelectedIndex > 0)
                {
                    txtname.Text = cmbselectprogram.Text + " " + cmbselectsemester.Text;
                }
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtname.Text.Length == 0)
            {
                ep.SetError(txtname, "Please Select Again!!");
                txtname.Focus();
                txtname.SelectAll();
                return;
            }

            if (txtcapacity.Text.Length == 0)
            {
                ep.SetError(txtcapacity, "Please enter capacity!!");
                txtcapacity.Focus();
                txtcapacity.SelectAll();
                return;
            }

            if (cmbselectprogram.SelectedIndex == 0)
             {
                ep.SetError(cmbselectprogram, "Please Select Program!!");
                cmbselectprogram.Focus();
                cmbselectprogram.SelectAll();
                 return;
             }

            if (cmbselectsemester.SelectedIndex == 0)
            {
                ep.SetError(cmbselectsemester, "Please Select Semester!!");
                cmbselectsemester.Focus();
                cmbselectsemester.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from ProgramSemesterTable where ProgramID= '" + cmbselectprogram.SelectedValue + "' and SemesterID = '" + cmbselectsemester.SelectedValue +"'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtname, " Already Exists!!");
                    txtname.Focus();
                    txtname.SelectAll();
                    return;
                }
            }

            string insertquery = string.Format("insert into ProgramSemesterTable(Title,ProgramID,SemesterID,Capacity,IsActive) values('{0}','{1}','{2}','{3}','{4}')", txtname.Text.Trim(), cmbselectprogram.SelectedValue, cmbselectsemester.SelectedValue, txtcapacity.Text.Trim(),chkstatus.Checked);
            bool result = DBLayer.Insert(insertquery);
            if (result == true)
            {
                MessageBox.Show("Saved Successfuly!!");
                //FillGrid(string.Empty);
                SaveClearForm();
            }
            else
            {
                MessageBox.Show("Please provide correct details and try again!!");
            }
        }

        public void ClearForm()
        {
            txtname.Clear();
            cmbselectsemester.SelectedIndex = 0;
            cmbselectprogram.SelectedIndex = 0;
            txtcapacity.Clear();
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void SaveClearForm()
        {
            txtname.Clear();
            txtcapacity.Clear();
            cmbselectsemester.SelectedIndex = 0;
            chkstatus.Checked = true;
            FillGrid(string.Empty);

        }

        public void EnableComponents()
        {
            dgvProgSem.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            btncancel.Visible = true;
            btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvProgSem.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            btncancel.Visible = false;
            btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }


        private void cmsedit_Click(object sender, EventArgs e)
        {
            if (dgvProgSem != null)
            {
                if (dgvProgSem.Rows.Count > 0)
                {
                    if (dgvProgSem.SelectedRows.Count == 1)
                    {
                        txtname.Text = Convert.ToString(dgvProgSem.CurrentRow.Cells[1].Value);
                        txtcapacity.Text = Convert.ToString(dgvProgSem.CurrentRow.Cells[2].Value);
                        cmbselectprogram.SelectedValue = Convert.ToString(dgvProgSem.CurrentRow.Cells[4].Value);
                        cmbselectsemester.SelectedValue = Convert.ToString(dgvProgSem.CurrentRow.Cells[5].Value);
                        chkstatus.Checked = Convert.ToBoolean(dgvProgSem.CurrentRow.Cells[3].Value);
                        EnableComponents();
                    }
                    else
                    {
                        MessageBox.Show("Please select one Record!!");
                    }
                }
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            ep.Clear();
            if (txtname.Text.Length == 0)
            {
                ep.SetError(txtname, "Please Select Again!!");
                txtname.Focus();
                txtname.SelectAll();
                return;
            }

            if (txtcapacity.Text.Length == 0)
            {
                ep.SetError(txtcapacity, "Please enter capacity!!");
                txtcapacity.Focus();
                txtcapacity.SelectAll();
                return;
            }

            if (cmbselectprogram.SelectedIndex == 0)
            {
                ep.SetError(cmbselectprogram, "Please Select Correct Program!!");
                cmbselectprogram.Focus();
                cmbselectprogram.SelectAll();
                return;
            }

            if (cmbselectsemester.SelectedIndex == 0)
            {
                ep.SetError(cmbselectsemester, "Please Select Correct Semester!!");
                cmbselectsemester.Focus();
                cmbselectsemester.SelectAll();
                return;
            }

            DataTable checktitle = DBLayer.Retrieve("select * from ProgramSemesterTable where ProgramID= '" + cmbselectprogram.SelectedValue + "' and SemesterID = '" + cmbselectsemester.SelectedValue + "' and ProgramSemesterID != '" + Convert.ToString(dgvProgSem.CurrentRow.Cells[0].Value) + "'");
            if (checktitle != null)
            {
                if (checktitle.Rows.Count > 0)
                {
                    ep.SetError(txtname, " Already Exists!!");
                    txtname.Focus();
                    txtname.SelectAll();
                    return;
                }
            }

            string updatequery = string.Format("update ProgramSemesterTable set Title='{0}', ProgramID='{1}', SemesterID= '{2}', Capacity = '{3}', IsActive='{4}' where ProgramSemesterID = '{5}' ", txtname.Text.Trim(), cmbselectprogram.SelectedValue, cmbselectsemester.SelectedValue, txtcapacity.Text.Trim(), chkstatus.Checked, Convert.ToString(dgvProgSem.CurrentRow.Cells[0].Value));
            bool result = DBLayer.Update(updatequery);
            if (result == true)
            {
                MessageBox.Show("Updated Successfuly!!");
                DisableComponents();
            }
            else
            {
                MessageBox.Show("Please provide correct details and try again!!");
            }
        }

        private void txtcapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
