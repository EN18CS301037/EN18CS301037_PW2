﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.SourceCode;


namespace TimeTableGenerator.Forms.ProgramSemesterForms
{
    public partial class ProgramSemSubForm : Form
    {
        public ProgramSemSubForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select ProgramSemesterSubjectID [ID], ProgramID, Program, ProgramSemesterID, Semester, FacultySubjectID, SemSubTitle [Subject], Capacity, IsSubjectActive [Status] from v_AllSemesterSubjects where ProgramSemesterIsActive = 1 and ProgramIsActive = 1 and SemesterIsActive = 1 and SubjectIsActive = 1 order by ProgramSemesterID";
                }
                else
                {
                    query = "select ProgramSemesterSubjectID [ID], ProgramID, Program, ProgramSemesterID, Semester, FacultySubjectID, SemSubTitle [Subject], Capacity, IsSubjectActive [Status] from v_AllSemesterSubjects where ProgramSemesterIsActive = 1 and ProgramIsActive = 1 and SemesterIsActive = 1 and SubjectIsActive = 1 and (Program +' ' +Semester + ' '+ SemSubTitle) like '%" + searchvalue.Trim() + "%' order by ProgramSemesterID";
                }

                DataTable lablist = DBLayer.Retrieve(query);
                dgvFacultySubject.DataSource = lablist;
                if (dgvFacultySubject.Rows.Count > 0)
                {
                    dgvFacultySubject.Columns[0].Visible = false;    //PSSID
                    dgvFacultySubject.Columns[1].Visible = false;  //PID
                    dgvFacultySubject.Columns[2].Width = 120;      //P
                    dgvFacultySubject.Columns[3].Visible = false; ;     //PSID
                    dgvFacultySubject.Columns[4].Width = 150;    // SEM
                    dgvFacultySubject.Columns[5].Visible = false;    //FSID
                    dgvFacultySubject.Columns[6].Width = 300;   //sUB
                    dgvFacultySubject.Columns[7].Width = 85;   //CAP
                    dgvFacultySubject.Columns[8].Width = 85;   //status
                    dgvFacultySubject.ClearSelection();

                }
            }
            catch
            {
                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        public void ClearForm()
        {
            txtTitle.Clear();
            cmbSemester.SelectedIndex = 0;
            cmbSubject.SelectedIndex = 0;
            //chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void SaveClearForm()
        {
            txtTitle.Clear();
            cmbSemester.SelectedIndex = 0;
            //chkstatus.Checked = true;
            FillGrid(string.Empty);

        }

        public void EnableComponents()
        {
            dgvFacultySubject.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
            //btncancel.Visible = true;
            //btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvFacultySubject.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            //btncancel.Visible = false;
            //btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void ProgramSemSubForm_Load(object sender, EventArgs e)
        {
            ComboHelper.AllProgramSems(cmbSemester);
            ComboHelper.AllFacultySubjects(cmbSubject);
            FillGrid(string.Empty);
        }


        private void cmbSubject_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtTitle.Text = cmbSubject.SelectedIndex == 0 ? string.Empty : cmbSubject.Text;
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cmbSemester.SelectedIndex == 0)
                {
                    ep.SetError(cmbSemester, "Please Select Semester!!");
                    cmbSemester.Focus();
                    cmbSemester.SelectAll();
                    return;
                }

                if (cmbSubject.SelectedIndex == 0)
                {
                    ep.SetError(cmbSubject, "Please Select Subject!!");
                    cmbSubject.Focus();
                    cmbSubject.SelectAll();
                    return;
                }

                if (txtTitle.Text.Trim().Length == 0)
                {
                    ep.SetError(txtTitle, "Please Select Semester & Subject again!!");
                    txtTitle.Focus();
                    txtTitle.SelectAll();
                    return;
                }


                string checkQuery = "select * from ProgramSemSubTable where ProgramSemesterID= '" + cmbSemester.SelectedValue + "' and FacultySubjectID = '" + cmbSubject.SelectedValue + "'";
                DataTable dt = DBLayer.Retrieve(checkQuery);
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        ep.SetError(cmbSubject, " Already Exists!!");
                        cmbSubject.Focus();
                        //cmbSubject.SelectAll();
                        return;
                    }
                }

                string insertquery = string.Format("insert into ProgramSemSubTable(SemSubTitle,ProgramSemesterID,FacultySubjectID) values('{0}','{1}','{2}')", txtTitle.Text.Trim(), cmbSemester.SelectedValue, cmbSubject.SelectedValue);
                bool result = DBLayer.Insert(insertquery);
                if (result == true)
                {
                    MessageBox.Show("Saved Successfuly!!");
                    FillGrid(string.Empty);
                    ClearForm();
                    //DisableComponents();
                }
                else
                {
                    MessageBox.Show("Please provide correct details and try again!!");
                }
            }
            catch
            {
                MessageBox.Show("Please check sql server agent connectivity!!");
            }
        }

        private void cmsedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvFacultySubject != null)
                {
                    if (dgvFacultySubject.Rows.Count > 0)
                    {
                        if (dgvFacultySubject.SelectedRows.Count == 1)
                        {
                            if (MessageBox.Show("You Surely want to update the selected record??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                bool existstatus = Convert.ToBoolean(dgvFacultySubject.CurrentRow.Cells[8].Value);
                                int SemesterSubID = Convert.ToInt32(dgvFacultySubject.CurrentRow.Cells[0].Value);
                                bool status = false;
                                if(existstatus == true)
                                {
                                    status = false;
                                }
                                else
                                {
                                    status = true;
                                }

                                string updatequery = string.Format("update ProgramSemSubTable set IsSubjectActive = '{0}' where ProgramSemesterSubjectID = '{1}'", status,SemesterSubID);
                                bool result = DBLayer.Update(updatequery);
                                if (result == true)
                                {
                                    MessageBox.Show("Subject Status Changed Successfully!!");
                                    FillGrid(string.Empty);
                                    //SaveClearForm();
                                    //DisableComponents();
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Please provide correct details and try again!!");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select one Record!!");
                        }
                    }
                }
            }
            catch
            {

            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void cmbSemester_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}



