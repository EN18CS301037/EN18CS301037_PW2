﻿
namespace TimeTableGenerator.Forms
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnProgram = new System.Windows.Forms.ToolStripButton();
            this.btnSessions = new System.Windows.Forms.ToolStripButton();
            this.btnSubjects = new System.Windows.Forms.ToolStripButton();
            this.btnAllFaculties = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnAddNewFaculty = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAssignSubjectsToFaculty = new System.Windows.Forms.ToolStripMenuItem();
            this.btnRoomsLabs = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnAddRooms = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddLabs = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSemesters = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnnewSemester = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddSectionsToSemester = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddSemesterToProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAddSubjectToSemester = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDays = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnAddDays = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDayTimeSlots = new System.Windows.Forms.ToolStripMenuItem();
            this.btnTTGenerator = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnAutoGenerateTimeTable = new System.Windows.Forms.ToolStripMenuItem();
            this.btnPrintTT = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnPrintStudentTT = new System.Windows.Forms.ToolStripMenuItem();
            this.btnPrintFacultyTT = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1386, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.toolStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnProgram,
            this.btnSessions,
            this.btnSubjects,
            this.btnAllFaculties,
            this.btnRoomsLabs,
            this.btnSemesters,
            this.btnDays,
            this.btnTTGenerator,
            this.btnPrintTT});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1386, 79);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnProgram
            // 
            this.btnProgram.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProgram.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProgram.Image = ((System.Drawing.Image)(resources.GetObject("btnProgram.Image")));
            this.btnProgram.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnProgram.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnProgram.Name = "btnProgram";
            this.btnProgram.Size = new System.Drawing.Size(134, 76);
            this.btnProgram.Text = "Program";
            this.btnProgram.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnProgram.Click += new System.EventHandler(this.btnProgram_Click);
            // 
            // btnSessions
            // 
            this.btnSessions.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSessions.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSessions.Image = ((System.Drawing.Image)(resources.GetObject("btnSessions.Image")));
            this.btnSessions.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSessions.Name = "btnSessions";
            this.btnSessions.Size = new System.Drawing.Size(143, 76);
            this.btnSessions.Text = "Sessions";
            this.btnSessions.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSessions.Click += new System.EventHandler(this.btnSessions_Click);
            // 
            // btnSubjects
            // 
            this.btnSubjects.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSubjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubjects.Image = ((System.Drawing.Image)(resources.GetObject("btnSubjects.Image")));
            this.btnSubjects.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSubjects.Name = "btnSubjects";
            this.btnSubjects.Size = new System.Drawing.Size(137, 76);
            this.btnSubjects.Text = "Subjects";
            this.btnSubjects.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSubjects.Click += new System.EventHandler(this.btnSubjects_Click);
            // 
            // btnAllFaculties
            // 
            this.btnAllFaculties.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnAllFaculties.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddNewFaculty,
            this.btnAssignSubjectsToFaculty});
            this.btnAllFaculties.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllFaculties.Image = ((System.Drawing.Image)(resources.GetObject("btnAllFaculties.Image")));
            this.btnAllFaculties.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAllFaculties.Name = "btnAllFaculties";
            this.btnAllFaculties.Size = new System.Drawing.Size(197, 76);
            this.btnAllFaculties.Text = "All Faculties";
            this.btnAllFaculties.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnAddNewFaculty
            // 
            this.btnAddNewFaculty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewFaculty.Name = "btnAddNewFaculty";
            this.btnAddNewFaculty.Size = new System.Drawing.Size(363, 30);
            this.btnAddNewFaculty.Text = "Add New Faculty";
            this.btnAddNewFaculty.Click += new System.EventHandler(this.btnAddNewFaculty_Click);
            // 
            // btnAssignSubjectsToFaculty
            // 
            this.btnAssignSubjectsToFaculty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignSubjectsToFaculty.Name = "btnAssignSubjectsToFaculty";
            this.btnAssignSubjectsToFaculty.Size = new System.Drawing.Size(363, 30);
            this.btnAssignSubjectsToFaculty.Text = "Assign Subjects To Faculty";
            this.btnAssignSubjectsToFaculty.Click += new System.EventHandler(this.btnAssignSubjectsToFaculty_Click);
            // 
            // btnRoomsLabs
            // 
            this.btnRoomsLabs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnRoomsLabs.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddRooms,
            this.btnAddLabs});
            this.btnRoomsLabs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoomsLabs.Image = ((System.Drawing.Image)(resources.GetObject("btnRoomsLabs.Image")));
            this.btnRoomsLabs.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRoomsLabs.Name = "btnRoomsLabs";
            this.btnRoomsLabs.Size = new System.Drawing.Size(214, 76);
            this.btnRoomsLabs.Text = "Rooms / Labs";
            this.btnRoomsLabs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnAddRooms
            // 
            this.btnAddRooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddRooms.Name = "btnAddRooms";
            this.btnAddRooms.Size = new System.Drawing.Size(318, 30);
            this.btnAddRooms.Text = "Add / Edit Classrooms";
            this.btnAddRooms.Click += new System.EventHandler(this.btnAddRooms_Click);
            // 
            // btnAddLabs
            // 
            this.btnAddLabs.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddLabs.Name = "btnAddLabs";
            this.btnAddLabs.Size = new System.Drawing.Size(318, 30);
            this.btnAddLabs.Text = "Add / Edit Labs";
            this.btnAddLabs.Click += new System.EventHandler(this.btnAddLabs_Click);
            // 
            // btnSemesters
            // 
            this.btnSemesters.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSemesters.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnnewSemester,
            this.btnAddSectionsToSemester,
            this.btnAddSemesterToProgram,
            this.btnAddSubjectToSemester});
            this.btnSemesters.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSemesters.Image = ((System.Drawing.Image)(resources.GetObject("btnSemesters.Image")));
            this.btnSemesters.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSemesters.Name = "btnSemesters";
            this.btnSemesters.Size = new System.Drawing.Size(173, 76);
            this.btnSemesters.Text = "Semesters";
            this.btnSemesters.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnnewSemester
            // 
            this.btnnewSemester.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnewSemester.Name = "btnnewSemester";
            this.btnnewSemester.Size = new System.Drawing.Size(366, 30);
            this.btnnewSemester.Text = "New Semester";
            this.btnnewSemester.Click += new System.EventHandler(this.btnnewSemester_Click);
            // 
            // btnAddSectionsToSemester
            // 
            this.btnAddSectionsToSemester.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSectionsToSemester.Name = "btnAddSectionsToSemester";
            this.btnAddSectionsToSemester.Size = new System.Drawing.Size(366, 30);
            this.btnAddSectionsToSemester.Text = "Add Sections To Semester ";
            this.btnAddSectionsToSemester.Click += new System.EventHandler(this.btnAddSectionsToSemester_Click);
            // 
            // btnAddSemesterToProgram
            // 
            this.btnAddSemesterToProgram.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSemesterToProgram.Name = "btnAddSemesterToProgram";
            this.btnAddSemesterToProgram.Size = new System.Drawing.Size(366, 30);
            this.btnAddSemesterToProgram.Text = "Add Semester To Program";
            this.btnAddSemesterToProgram.Click += new System.EventHandler(this.btnAddSemesterToProgram_Click);
            // 
            // btnAddSubjectToSemester
            // 
            this.btnAddSubjectToSemester.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSubjectToSemester.Name = "btnAddSubjectToSemester";
            this.btnAddSubjectToSemester.Size = new System.Drawing.Size(366, 30);
            this.btnAddSubjectToSemester.Text = "Add Subject To Semester ";
            this.btnAddSubjectToSemester.Click += new System.EventHandler(this.btnAddSubjectToSemester_Click);
            // 
            // btnDays
            // 
            this.btnDays.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDays.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddDays,
            this.btnDayTimeSlots});
            this.btnDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDays.Image = ((System.Drawing.Image)(resources.GetObject("btnDays.Image")));
            this.btnDays.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDays.Name = "btnDays";
            this.btnDays.Size = new System.Drawing.Size(97, 76);
            this.btnDays.Text = "Days";
            this.btnDays.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnAddDays
            // 
            this.btnAddDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDays.Name = "btnAddDays";
            this.btnAddDays.Size = new System.Drawing.Size(252, 30);
            this.btnAddDays.Text = "Add / Edit Days";
            this.btnAddDays.Click += new System.EventHandler(this.btnAddDays_Click);
            // 
            // btnDayTimeSlots
            // 
            this.btnDayTimeSlots.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDayTimeSlots.Name = "btnDayTimeSlots";
            this.btnDayTimeSlots.Size = new System.Drawing.Size(252, 30);
            this.btnDayTimeSlots.Text = "Day Time Slots";
            this.btnDayTimeSlots.Click += new System.EventHandler(this.btnDayTimeSlots_Click);
            // 
            // btnTTGenerator
            // 
            this.btnTTGenerator.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTTGenerator.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAutoGenerateTimeTable});
            this.btnTTGenerator.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTTGenerator.Image = ((System.Drawing.Image)(resources.GetObject("btnTTGenerator.Image")));
            this.btnTTGenerator.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTTGenerator.Name = "btnTTGenerator";
            this.btnTTGenerator.Size = new System.Drawing.Size(173, 76);
            this.btnTTGenerator.Text = "TimeTable";
            this.btnTTGenerator.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnAutoGenerateTimeTable
            // 
            this.btnAutoGenerateTimeTable.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutoGenerateTimeTable.Name = "btnAutoGenerateTimeTable";
            this.btnAutoGenerateTimeTable.Size = new System.Drawing.Size(349, 30);
            this.btnAutoGenerateTimeTable.Text = "Auto Generate TimeTable";
            this.btnAutoGenerateTimeTable.Click += new System.EventHandler(this.btnAutoGenerateTimeTable_Click);
            // 
            // btnPrintTT
            // 
            this.btnPrintTT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPrintTT.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnPrintStudentTT,
            this.btnPrintFacultyTT});
            this.btnPrintTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintTT.Image = ((System.Drawing.Image)(resources.GetObject("btnPrintTT.Image")));
            this.btnPrintTT.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPrintTT.Name = "btnPrintTT";
            this.btnPrintTT.Size = new System.Drawing.Size(93, 76);
            this.btnPrintTT.Text = "Print";
            this.btnPrintTT.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnPrintStudentTT
            // 
            this.btnPrintStudentTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintStudentTT.Name = "btnPrintStudentTT";
            this.btnPrintStudentTT.Size = new System.Drawing.Size(360, 30);
            this.btnPrintStudentTT.Text = "Print Student TimeTable";
            this.btnPrintStudentTT.Click += new System.EventHandler(this.btnPrintStudentTT_Click);
            // 
            // btnPrintFacultyTT
            // 
            this.btnPrintFacultyTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintFacultyTT.Name = "btnPrintFacultyTT";
            this.btnPrintFacultyTT.Size = new System.Drawing.Size(360, 30);
            this.btnPrintFacultyTT.Text = "Print All Faculty TimeTable";
            this.btnPrintFacultyTT.Click += new System.EventHandler(this.btnPrintFacultyTT_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(1386, 450);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.ForeColor = System.Drawing.Color.Black;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Home_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnProgram;
        private System.Windows.Forms.ToolStripButton btnSessions;
        private System.Windows.Forms.ToolStripButton btnSubjects;
        private System.Windows.Forms.ToolStripDropDownButton btnAllFaculties;
        private System.Windows.Forms.ToolStripDropDownButton btnRoomsLabs;
        private System.Windows.Forms.ToolStripMenuItem btnAddRooms;
        private System.Windows.Forms.ToolStripMenuItem btnAddLabs;
        private System.Windows.Forms.ToolStripDropDownButton btnSemesters;
        private System.Windows.Forms.ToolStripMenuItem btnnewSemester;
        private System.Windows.Forms.ToolStripMenuItem btnAddSectionsToSemester;
        private System.Windows.Forms.ToolStripMenuItem btnAddSemesterToProgram;
        private System.Windows.Forms.ToolStripMenuItem btnAddSubjectToSemester;
        private System.Windows.Forms.ToolStripDropDownButton btnDays;
        private System.Windows.Forms.ToolStripMenuItem btnAddDays;
        private System.Windows.Forms.ToolStripMenuItem btnDayTimeSlots;
        private System.Windows.Forms.ToolStripDropDownButton btnTTGenerator;
        private System.Windows.Forms.ToolStripMenuItem btnAutoGenerateTimeTable;
        private System.Windows.Forms.ToolStripDropDownButton btnPrintTT;
        private System.Windows.Forms.ToolStripMenuItem btnPrintStudentTT;
        private System.Windows.Forms.ToolStripMenuItem btnPrintFacultyTT;
        private System.Windows.Forms.ToolStripMenuItem btnAddNewFaculty;
        private System.Windows.Forms.ToolStripMenuItem btnAssignSubjectsToFaculty;
    }
}