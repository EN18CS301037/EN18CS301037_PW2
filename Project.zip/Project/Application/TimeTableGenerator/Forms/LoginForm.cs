﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using TimeTableGenerator.Reports;

namespace TimeTableGenerator.Forms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            if (txtusername.Text.Length == 0)
            {
                ep.SetError(txtusername, "Please Enter Username!!");
                txtusername.Focus();
                txtusername.SelectAll();
                return;
            }

            if (txtpassword.Text.Length == 0)
            {
                ep.SetError(txtpassword, "Please Enter Password!!");
                txtpassword.Focus();
                txtpassword.SelectAll();
                return;
            }

            string loginquery = string.Format("Select UserName,Password from UserTable");
            bool result = DBLayer.Insert(loginquery);
            if (txtusername.Text.Trim() == "Admin" && txtpassword.Text.Trim() == "admin123" )
            {
                MessageBox.Show("Login Successfull!!");
                this.Hide();
                Home frm = new Home();
                frm.ShowDialog();
            }
            else if (txtusername.Text.Trim() == "Teacher" && txtpassword.Text.Trim() == "teacher123")
            {
                MessageBox.Show("Login Successfull!!");
                this.Hide();
                PrintAllTeachersTT frm = new PrintAllTeachersTT();
                frm.ShowDialog();
            }

            else if ((txtusername.Text.Trim() == "Anisha" && txtpassword.Text.Trim() == "anisha") || (txtusername.Text.Trim() == "Aditi" && txtpassword.Text.Trim() == "aditi") || (txtusername.Text.Trim() == "Akshita" && txtpassword.Text.Trim() == "akshita"))
            {
                MessageBox.Show("Login Successfull!!");
                this.Hide();
                PrintAllSemTt frm = new PrintAllSemTt();
                frm.ShowDialog();
            }

            else
            {
                MessageBox.Show("Please provide correct Credentials and try again!!");
            }
            
        }
    }
}
