﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TimeTableGenerator.SourceCode;

namespace TimeTableGenerator.Forms.FacultySubjectForms
{
    public partial class FacultySubjectForm : Form
    {
        public FacultySubjectForm()
        {
            InitializeComponent();
        }

        public void FillGrid(string searchvalue)
        {

            try
            {
                string query = string.Empty;
                if (string.IsNullOrEmpty(searchvalue.Trim()))
                {
                    query = "select FacultySubjectID [ID], SubjectTitle [Subject Name],FacultyID,FullName [Faculty],CourseID,Title [Subject],IsActive [Status] from v_AllSubjectTeachers order by FullName";
                }
                else
                {
                    query = "select FacultySubjectID [ID], SubjectTitle [Subject Name],FacultyID, FullName [Faculty],CourseID,Title [Subject],IsActive [Status] from v_AllSubjectTeachers where (SubjectTitle +' ' +FullName) like '%" + searchvalue.Trim() + "%' order by FullName";
                }

                DataTable lablist = DBLayer.Retrieve(query);
                dgvFacultySubject.DataSource = lablist;
                if (dgvFacultySubject.Rows.Count > 0)
                {
                    dgvFacultySubject.Columns[0].Visible = false;    //fsid
                    dgvFacultySubject.Columns[1].Width = 300;       //subname
                    dgvFacultySubject.Columns[2].Visible = false;  //fid
                    dgvFacultySubject.Columns[3].Width = 120;     //fname
                    dgvFacultySubject.Columns[4].Visible = false;// cid
                    dgvFacultySubject.Columns[5].Width = 240;   //cname
                    dgvFacultySubject.Columns[6].Width = 80;   //status

                }
            }
            catch
            {
                MessageBox.Show("Some unexpected issue occured please try again");
            }
        }

        public void ClearForm()
        {
           //txtname.Clear();
            cmbFaculty.SelectedIndex = 0;
            cmbSubject.SelectedIndex = 0;
            chkstatus.Checked = false;
            FillGrid(string.Empty);
        }

        public void SaveClearForm()
        {
            //txtname.Clear();
            cmbFaculty.SelectedIndex = 0;
            chkstatus.Checked = true;
            FillGrid(string.Empty);

        }

        public void EnableComponents()
        {
            dgvFacultySubject.Enabled = false;
            btnclear.Visible = false;
            btnsave.Visible = false;
           //btncancel.Visible = true;
           //btnupdate.Visible = true;
            txtsearch.Enabled = false;
        }

        public void DisableComponents()
        {
            dgvFacultySubject.Enabled = true;
            btnclear.Visible = true;
            btnsave.Visible = true;
            //btncancel.Visible = false;
            //btnupdate.Visible = false;
            txtsearch.Enabled = true;
            ClearForm();
            FillGrid(string.Empty);
        }

        private void FacultySubjectForm_Load(object sender, EventArgs e)
        {
            ComboHelper.Faculty(cmbFaculty);
            ComboHelper.Subject(cmbSubject);
            FillGrid(string.Empty);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            DisableComponents();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ep.Clear();
                if (cmbFaculty.SelectedIndex == 0)
                {
                    ep.SetError(cmbFaculty, "Please Select Faculty!!");
                    cmbFaculty.Focus();
                    cmbFaculty.SelectAll();
                    return;
                }

                if (cmbSubject.SelectedIndex == 0)
                {
                    ep.SetError(cmbSubject, "Please Select Subject!!");
                    cmbSubject.Focus();
                    cmbSubject.SelectAll();
                    return;
                }

                DataTable checktitle = DBLayer.Retrieve("select * from FacultySubjectTable where FacultyID= '" + cmbFaculty.SelectedValue + "' and CourseID = '" + cmbSubject.SelectedValue + "'");
                if (checktitle != null)
                {
                    if (checktitle.Rows.Count > 0)
                    {
                        ep.SetError(cmbSubject, " Already Exists!!");
                        cmbSubject.Focus();
                        cmbSubject.SelectAll();
                        return;
                    }
                }

                string insertquery = string.Format("insert into FacultySubjectTable(SubjectTitle,FacultyID,CourseID,IsActive) values('{0}','{1}','{2}','{3}')", cmbSubject.Text+" ("+cmbFaculty.Text+")", cmbFaculty.SelectedValue, cmbSubject.SelectedValue, chkstatus.Checked);
                bool result = DBLayer.Insert(insertquery);
                if (result == true)
                {
                    MessageBox.Show("Saved Successfuly!!");
                    //FillGrid(string.Empty);
                    //SaveClearForm();
                    DisableComponents();
                }
                else
                {
                    MessageBox.Show("Please provide correct details and try again!!");
                }
            }
            catch
            {
                MessageBox.Show("Please check sql server agent connectivity!!");
            }
        }


        private void cmsedit_Click(object sender, EventArgs e)
        {
            try
            {
                if(dgvFacultySubject != null)
                {
                    if (dgvFacultySubject.Rows.Count > 0)
                    {
                        if (dgvFacultySubject.SelectedRows.Count == 1)
                        {
                            if (MessageBox.Show("You Surely want to update the selected record??", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                string id = Convert.ToString(dgvFacultySubject.CurrentRow.Cells[0].Value);
                                bool status = Convert.ToBoolean(dgvFacultySubject.CurrentRow.Cells[6].Value) == true ? false : true;

                                string updatequery = "update FacultySubjectTable set IsActive = '" + status + "' where FacultySubjectID = '" + id + "'";
                                bool result = DBLayer.Update(updatequery);
                                if (result == true)
                                {
                                    MessageBox.Show("Subject Status Changed Successfully!!");
                                    //FillGrid(string.Empty);
                                    //SaveClearForm();
                                    DisableComponents();
                                    return;
                                }
                                else
                                {
                                    MessageBox.Show("Please provide correct details and try again!!");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select one Record!!");
                        }
                    }
                }
            }
            catch
            {

            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            FillGrid(txtsearch.Text.Trim());
            
        }

        private void dgvFacultySubject_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
